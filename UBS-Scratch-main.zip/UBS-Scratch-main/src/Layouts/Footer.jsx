import React from "react";
import "./Footer.css";
import {
  FaFacebook,
  FaHome,
  FaInstagram,
  FaLinkedin,
  FaYoutube,
} from "react-icons/fa";
import Logo from "../assets/FLogo.png";
import { Link } from "react-router-dom";
import { CgMail, CgPhone } from "react-icons/cg";

const Footer = () => {
  // const mail = () => {
  //   window.location.href = "mailto:careerhubtechnology@gmail.com";
  // };

  return (
    <footer className="footer">
      <div className="footer-container">
        <div className="footer-section">
          <div className="footer-icon">
            <div
              onClick={() => window.location.reload()}
              style={{ color: "#fff" }}
            >
              UBS<span style={{ fontSize: "22px" }}>Bill</span>
            </div>
          </div>
          <p>
            Complete Restaurant Management — Billing, CRM, Inventory & More.
          </p>

          <div className="footer-icon">
            <FaHome className="blue-text" />
          </div>
          <h2 className="blue-text">Address</h2>
          <p>
            Shree Ganesh Building,First floor No-101, Gurudwara Chowk, Akurdi,
            Pune Maharashtra-411033.
          </p>
        </div>

        <div className="footer-section padl">
          <div className="footer-icon">
            {/* <span className="orange-text">✦</span> */}
          </div>
          <h2 className="blue-text">Quick Links</h2>
          <ul>
            <li>
              <Link to="/" className="footer-link">
                Home
              </Link>
            </li>
            <li>
              <Link to="/Aboutus" className="footer-link">
                About Us
              </Link>
            </li>
            <li>
              <Link to="/b2bpartner" className="footer-link">
                B2BPartner
              </Link>
            </li>
            <li>
              <Link to="/Individual" className="footer-link">
                Individual Sales
              </Link>
            </li>
            <li>
              <Link to="/pricing" className="footer-link">
                Pricing
              </Link>
            </li>
            <li>
              <Link to="/contact" className="footer-link">
                Contact
              </Link>
            </li>
            <li>
              <Link to="/career" className="footer-link">
                Career
              </Link>
            </li>
          </ul>
        </div>

        <div className="footer-section">
          <div className="footer-icon">
            {/* <span className="orange-text">✦</span> */}
          </div>
          <h2 className="blue-text">Outlet Types</h2>
          <ul>
            <li>
              <Link to="/qsr" className="footer-link">
                QSR
              </Link>
            </li>
            <li>
              <Link to="/cloudkitchen" className="footer-link">
                Cloud Kitchen
              </Link>
            </li>
            <li>
              <Link to="/fc" className="footer-link">
                Food Court
              </Link>
            </li>
            <li>
              <Link to="/foodchain" className="footer-link">
                Food Chain
              </Link>
            </li>
            <li>
              <Link to="/fow" className="footer-link">
                Food on Wheels
              </Link>
            </li>
            <li>
              <Link to="/i&d" className="footer-link">
                Icecreams & Deserts
              </Link>
            </li>
            <li>
              <Link to="/juicery" className="footer-link">
                Juicery
              </Link>
            </li>
            <li>
              <Link to="/bakery" className="footer-link">
                Bakery
              </Link>
            </li>
            <li>
              <Link to="/rest" className="footer-link">
                Restaurant
              </Link>
            </li>
            <li>
              <Link to="/cafe" className="footer-link">
                Cafe
              </Link>
            </li>
            <li>
              <Link to="/hotel" className="footer-link">
                Hotel
              </Link>
            </li>
          </ul>
        </div>

        <div className="footer-section">
          <div className="footer-icon">
            {/* <span className="orange-text">✦</span> */}
          </div>
          <h2 className="blue-text">Connect With Us</h2>
          <br />
          <p>
            <a href="tel:+919112113322" className="blue-text">
              <CgPhone style={{ fontSize: "25px" }} /> +91 911 211 3322 <br />{" "}
            </a>
            <a className="blue-text">
              <CgMail style={{ fontSize: "25px" }} /> info@ubsbill.com
            </a>
          </p>
          <br /> <br /> <br /> <br />
          <div className="social-icons">
            <a
              href="https://www.linkedin.com/company/ubs-bill/"
              target="_blank"
              rel="noopener noreferrer"
            >
              <FaLinkedin className="blue-text" />
            </a>
            <a
              href="https://www.instagram.com/ubs_bill/"
              target="_blank"
              rel="noopener noreferrer"
            >
              <FaInstagram className="blue-text" />
            </a>
            <a
              href="https://www.facebook.com/ubsbill/about/"
              target="_blank"
              rel="noopener noreferrer"
            >
              <FaFacebook className="blue-text" />
            </a>
            <a
              href="https://www.youtube.com/watch?v=ewyIL8WgsC8"
              target="_blank"
              rel="noopener noreferrer"
            >
              <FaYoutube className="blue-text" />
            </a>
          </div>
        </div>
      </div>
      <div className="footer-bottom">
        <p style={{ letterSpacing: "2px" }}>
          Design and Developed By{" "}
          <a
            href="https://www.syntiaro.com"
            target="_blank"
            rel="noopener noreferrer"
            style={{ color: "white", textDecoration: "none" }}
          >
            SYNTIARO
          </a>
        </p>
      </div>
    </footer>
  );
};

export default Footer;
