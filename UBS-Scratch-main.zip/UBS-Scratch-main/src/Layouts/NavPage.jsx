import React from "react";
import { useState } from "react";
import { Link } from "react-router-dom";
import "../App.css";
import "./Navbar.css";
import Logo from "../assets/logo.png";
import Products from "../Components/Product";
import Outlettype from "../Components/Outlettype";
import Resource from "../Components/Resourse";
import AssociateDrop from "../Components/AssociateDrop";

const NavPage = () => {
  const [isOpen, setIsOpen] = useState(false);

  // eslint-disable-next-line no-empty-pattern
  const [] = useState(false);

  return (
    <>
      <nav className="navbar navbar-toggler" style={{ maxWidth: "100vw" }}>
        <div className="container" style={{ margin: "0", flexWrap: "nowrap" }}>
          {/* Menu Items */}

          <div
            className="logo-text-wrapper"
            onClick={() => window.location.reload()}
          >
            <img
              src={Logo}
              alt="logo"
              className="img-fluid-logo logo"
            />
          </div>

          <ul className={`nav-links ${isOpen ? "open" : ""}`}>
            <li>
              <Link to="/">Home</Link>
            </li>
            <li className="nav-item">
              <span className="courses">Products</span>

              {/* {showCourses && ( */}
              <div className="course-dropdown active">
                <Products />
              </div>
              {/* )} */}
            </li>

            <li className="nav-item">
              <span className="courses">Outlet Type</span>

              {/* {showCourses && ( */}
              <div className="course-dropdown active">
                <Outlettype />
              </div>
              {/* )} */}
            </li>
            <li>
              <Link to="/pricing">Pricing</Link>
            </li>
            <li className="nav-item">
              <span className="courses">Associate</span>

              {/* {showCourses && ( */}
              <div className="course-dropdown active">
                <AssociateDrop />
              </div>
              {/* )} */}
            </li>
            <li>
              <Link to="/ubsbill">UBS Cart</Link>
            </li>
            <li className="nav-item">
              <span className="courses">Resources</span>

              {/* {showCourses && ( */}
              <div className="course-dropdown active">
                <Resource />
              </div>
              {/* )} */}
            </li>
          </ul>

          {/* Hamburger Menu */}
          <div className="hamburger" onClick={() => setIsOpen(!isOpen)}>
            <div className={isOpen ? "bar open" : "bar"}></div>
            <div className={isOpen ? "bar open" : "bar"}></div>
            <div className={isOpen ? "bar open" : "bar"}></div>
          </div>
        </div>
      </nav>
    </>
  );
};

export default NavPage;
