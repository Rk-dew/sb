import React from "react";
import { Carousel, Button } from "react-bootstrap";
import { Link } from "react-router-dom";
import "./Caro.css";

const Caro = (props) => {
  return (
    <Carousel className="carousel">
      {props.carouselItems && props.carouselItems.length > 0 ? (
        props.carouselItems.map((item, index) => (
          <Carousel.Item key={index}>
            <img
              className="d-block w-100"
              src={item.imgPath}
              alt={`carousel-slide-${index}`}
            />
            <Carousel.Caption>
              <Button className="caro-btn caro-desc" as={Link} to={item.ctaLink}>
                {item.ctaText}
              </Button>
            </Carousel.Caption>
          </Carousel.Item>
        ))
      ) : (
        <Carousel.Item>
          <div className="d-block w-100">
            <p>No items available</p>
          </div>
        </Carousel.Item>
      )}
    </Carousel>
  );
};
export default Caro;