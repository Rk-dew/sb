import React from "react";
import "./App.css";
import { Route, Routes } from "react-router-dom";
import Home from "./Components/Home";
import Contact from "./Components/Contact";
import Aboutus from "./Components/Aboutus";
import Footer from "./Layouts/Footer";
import NavPage from "./Layouts/NavPage";
import EnquiryPopup from "./Components/EnquiryPopup";
import "./Components/EnquiryPopup.css";
import CourseEnquiry from "./Components/Outlets/CourseEnquiry";
import RestaurantPOS from "./Components/Outlets/RestaurantPOS";
import UBSBill from "./Components/UBUBill";
import Associate from "./Components/Associate";
import RetailPOS from "./Components/Outlets/RetailPOS";
import Qsr from "./Components/Outlets/Qsr";
import CloudKitchen from "./Components/Outlets/CloudKitchen";
import FoodCourt from "./Components/Outlets/FoodCourt";
import FoodChain from "./Components/Outlets/FoodChain";
import Fow from "./Components/Outlets/Fow";
import Icecreame from "./Components/Outlets/Icecreame";
import Juicery from "./Components/Outlets/Juicery";
import Bakery from "./Components/Outlets/Bakery";
import Restaurant from "./Components/Outlets/Restaurant";
import Cafe from "./Components/Outlets/Cafe";
import Hotel from "./Components/Outlets/Hotel";
import Career from "./Components/Career";
import LMS from "./Components/Outlets/LMS";
import Sales from "./Components/Associate/sales";
import B2BPartner from "./Components/Associate/b2bpartner";
import Pricing from "./Components/Pricing";

function App() {

  return (
    <>
      {/* Navbar */}
      <NavPage />

      <Routes>
        <Route exact path="/" element={<Home />} />
        <Route exact path="/Aboutus" element={<Aboutus />} />
        <Route exact path="/Contact" element={<Contact />} />
        <Route exact path="/Footer" element={<Footer />} />
        <Route exact path="/enquiry" element={<EnquiryPopup />} />
        <Route exact path="/courseinquiry" element={<CourseEnquiry />} />
        <Route exact path="/restpos" element={<RestaurantPOS />} />
        <Route exact path="/UBSBill" element={<UBSBill />} />
        <Route exact path="/career" element={<Career />} />
        <Route exact path="/sales" element={<Sales />} />
        <Route exact path="/b2bpartner" element={<B2BPartner />} />
        <Route exact path="/ubsbill" element={<UBSBill />} />
        <Route exact path="/pricing" element={<Pricing />} />

        {/* Products */}
        <Route exact path="/restpos" element={<RestaurantPOS />} />
        <Route exact path="/retailpos" element={<RetailPOS />} />
        <Route exact path="/lms" element={<LMS />} />
        {/* Outlet */}
        <Route exact path="/qsr" element={<Qsr />} />
        <Route exact path="/cloudkitchen" element={<CloudKitchen />} />
        <Route exact path="/fc" element={<FoodCourt />} />
        <Route exact path="/foodchain" element={<FoodChain />} />
        <Route exact path="/fow" element={<Fow />} />
        <Route exact path="/i&d" element={<Icecreame />} />
        <Route exact path="/juicery" element={<Juicery />} />
        <Route exact path="/bakery" element={<Bakery />} />
        <Route exact path="/rest" element={<Restaurant />} />
        <Route exact path="/cafe" element={<Cafe />} />
        <Route exact path="/hotel" element={<Hotel />} />
      </Routes>

      {/* Floating Button Apply */}

      <EnquiryPopup />
      <Footer />
    </>
  );
}

export default App;
