import React from "react";
import "./MVV.css";
import MissionImage from "../assets/About/mission.png";

const missionPoints = [
  {
    title: "Restaurant Excellence",
    description:
      "We provide restaurant POS software that simplifies order handling, kitchen operations, and improves customer satisfaction.",
  },
  {
    title: "Fashion Forward",
    description:
      "Our garment store solutions streamline inventory, boost sales, and elevate customer experience.",
  },
  {
    title: "Supermarket Efficiency",
    description:
      "We optimize supermarket operations with software that ensures inventory accuracy and fast checkout.",
  },
  {
    title: "Education Enhancement",
    description:
      "Our school and college software improves admin tasks, communication, and the learning experience.",
  },
  {
    title: "Salon and Spa Bliss",
    description:
      "We enhance salon and spa operations with tools for booking, client management, and revenue tracking.",
  },
  {
    title: "Salesman Tracker",
    description:
      "Our tracker helps monitor and improve sales team performance, driving business growth.",
  },
];

const Mission = () => {
  return (
    <section className="mission-container">
      <div className="mission-left">
        <h2 className="mission-title">Mission</h2>
        <p className="mission-intro">
          At Syntiaro, our mission is to deliver smart POS software tailored for
          restaurants, garment stores, supermarkets, educational institutions,
          salons/spas, and sales teams. We simplify operations, improve
          management, and help businesses grow in the digital era. Our goals include:
        </p>
        <ul className="mission-list">
          {missionPoints.map((point, index) => (
            <li key={index}>
              <strong>{point.title}:</strong> {point.description}
            </li>
          ))}
        </ul>
      </div>
      <div className="mission-right">
        <img
          src={MissionImage}
          alt="Mission"
          className="mission-img"
        />
      </div>
    </section>
  );
};

export default Mission;