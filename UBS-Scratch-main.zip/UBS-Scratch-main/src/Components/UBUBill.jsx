import React from "react";
import "./UBSBill.css";
import Footer from "../Layouts/Footer";
import UBSImage from "../assets/UBSCart.png";


const UBSBill = () => {
    return (
      <div className="ubsbill-wrapper">
        
  
        <div className="ubsbill-image-container">
          <img
            src={UBSImage}
            alt="UBSBill Preview"
            className="ubsbill-main-image"
          />
        </div>
  
        <Footer />
      </div>
    );
  };
  
  export default UBSBill;