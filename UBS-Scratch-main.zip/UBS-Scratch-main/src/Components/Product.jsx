import React from "react"; 
import { Link } from "react-router-dom";
import "../Components/Product.css";
import "../Layouts/Navbar.css";
// import { motion } from "framer-motion";

const courses = [
  {
    name: "Restaurant POS",
    path: "/restpos",
  },
  {
    name: "Retail POS",
    path: "/retailpos",
  },
  {
    name: "LMS Software",
    path: "/lms",
  }
];

const Products = () => {
  return (
    // <motion.div
    //   initial={{ opacity: 0, y: 100, scale: 0.95 }}
    //   animate={{ opacity: 1, y: 0, scale: 1 }}
    //   transition={{ duration: 0.8, ease: "easeOut" }}
    //   className="course-container"
    // >
    <div className="course-container">
      <div className="grid">
        {courses.map((course, index) => (
          <div key={index} className="card-container">
            <Link to={course.path} className="card-link">
              <div className="card">
                <span>{course.name}</span>
              </div>
            </Link>
          </div>
        ))}
      </div></div>
    // </motion.div>
  );
};

export default Products;
