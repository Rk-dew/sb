import React, { useEffect, useState } from "react";
import axios from "axios";
import "./EnquiryPopup.css";
import { CgClose } from "react-icons/cg";

const EnquiryPopup = () => {
  const [showPopup, setShowPopup] = useState(false);
  const [popupClosed, setPopupClosed] = useState(false); // NEW

  const [formData, setFormData] = useState({
    name: "",
    mobile: "",
    email: "",
    enquiry: "",
  });

  useEffect(() => {
    const timer = setTimeout(() => {
      if (!popupClosed) {
        setShowPopup(true);
      }
    }, 1000) // 10 sec

    return () => clearTimeout(timer);
  }, [popupClosed]);

  const handleClose = () => {
    setShowPopup(false);
    setPopupClosed(true); // NEW: Don't show again
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      console.log(formData);
      await axios.post("http://localhost:8080/mail/add", formData);
      console.log(formData);
      let result = await axios.post("http://localhost:8080/email/sendMail", formData);
      console.log(result);
      alert("Enquiry submitted successfully!");
      setFormData({
        name: "",
        mobile: "",
        email: "",
        enquiry: "",
      });
      setShowPopup(false);
      setPopupClosed(true);
    } catch (error) {
      console.error("Error submitting inquiry:", error);
      alert("Failed to submit inquiry. Please try again.");
    }
  };

  if (!showPopup) return null;

  return (
    <div className="popup-overlay">
      <div className="popup-box">
        <button className="close-btn" onClick={handleClose}>
          <CgClose />
        </button>
        <h3>Inquiry Form</h3>
        <form onSubmit={handleSubmit}>
          <input
            type="text"
            name="name"
            placeholder="Name"
            value={formData.name}
            onChange={handleChange}
            required
          />
          <input
            type="tel"
            name="mobile"
            placeholder="Mobile Number"
            value={formData.mobile}
            onChange={handleChange}
            required
          />
          <input
            type="email"
            name="email"
            placeholder="Email"
            value={formData.email}
            onChange={handleChange}
            required
          />
          <input
            type="text"
            name="enquiry"
            placeholder="Inquiry"
            value={formData.enquiry}
            onChange={handleChange}
            required
          />
          <button type="submit">Submit</button>
        </form>
      </div>
    </div>
  );
};

export default EnquiryPopup;