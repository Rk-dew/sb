import React, { useState } from "react";
import "./Career.css";
import Button from "react-bootstrap/Button";
import Nojob from "../assets/no-job.jpg";
import { FaArrowRight } from "react-icons/fa6";
import { AiOutlineClose } from "react-icons/ai";

const Career = () => {
  const [model, setModel] = useState(false);

  const toggleModel = () => {
    setModel(!model);
  };

  return (
    <>
      <section className="career-container mb-2 why">
        <div className="row">
          <div className="col-lg-9 col-md-12 order-md-1 order-2 align-center p-4">
            <p className="fs-1 text-muted text-left">
              Join Our Team: Build a Future with Us
            </p>
            <p className="lh-base text-muted text-justify">
              We’re not just building innovative solutions—we’re building a
              community of passionate, talented individuals who thrive on
              challenges and love making a difference.
            </p>
            <h4 className="pt-4 pb-2">Why Join Us?</h4>
            <ul className="career-list">
              <li>🔧 Real-World Projects: Work on live client projects.</li>
              <li>👨‍🏫 Mentorship: Learn from experienced professionals.</li>
              <li>💻 Skill Development: Use cutting-edge technologies.</li>
              <li>🤝 Networking: Connect with tech professionals.</li>
              <li>🚀 Career Opportunities: Perform well & get hired.</li>

              <Button variant="primary" onClick={toggleModel}>
                See Current Opportunities <FaArrowRight />
              </Button>
            </ul>
          </div>

          {model && (
            <div className="model">
              <div className="overlay" onClick={toggleModel}></div>
              <div className="model-content">
                <button
                  type="button"
                  className="close-btn"
                  onClick={toggleModel}
                >
                  <AiOutlineClose size={24} />
                </button>
                <h1 className="model-title">Open Position</h1>
                <div className="text-center">
                  <img
                    src={Nojob}
                    height={350}
                    alt="nojob"
                    className="img-why pt-2 mb-img"
                  />
                </div>
              </div>
            </div>
          )}
        </div>
      </section>
    </>
  );
};

export default Career;
