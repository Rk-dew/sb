import React from 'react';
import GoogleReview from './GoogleReview';

function App() {
    const reviews = [
        { reviewerName: 'Alice', reviewText: 'Great product! Highly recommend.', rating: 5 },
        { reviewerName: 'Bob', reviewText: 'It was okay, could be better.', rating: 4 },
        { reviewerName: 'Charlie', reviewText: 'Did not meet my expectations.', rating: 5 },
      ];
    
      return (
        <div className="app">
          <h1>Roogle Reviews</h1>
          {reviews.map((review, index) => (
            <GoogleReview
              key={index}
              reviewerName={review.reviewerName}
              reviewText={review.reviewText}
              rating={review.rating}
            />
          ))}
        </div>
      );
}

export default App;
