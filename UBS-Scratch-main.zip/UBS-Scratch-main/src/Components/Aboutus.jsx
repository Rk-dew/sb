import React from "react";
import "./Aboutus.css";
import What from "../assets/About/WhatWeDo.png";
import Mission from "./Mission";
import Vision from "./Vision";
import Values from "./Values";
import Softwares from "./Softwares";

const Aboutus = () => {
  return (
    <div className="about-container">
      <div className="about-intro">
        <h2 className="about-heading">
          Simplifying Restaurant Operations with Smart POS Solutions
        </h2>
        <p className="about-description">
          We are passionate about transforming the way restaurants operate. Our
          Restaurant POS System is built to empower restaurants, cafés, food
          trucks, cloud kitchens, and all types of food service businesses with
          efficient, reliable, and user-friendly technology.
        </p>
      </div>

      {/* Mission Vision Values */}
      <Vision />
      <Mission/>
      <Values />

      {/* Overlay Image */}
      <section className="gift">
        <div className="container">
          <div className="row">
            <h2 className="text-center fw-semibold">
              Bringing Your Brand to Life with Tailored Web Design, Expert
              Development, and Seamless Digital Experiences.
            </h2>
          </div>
        </div>
      </section>

      {/* What we do */}
      <section className="what-we-do-container">
        <div className="image-section">
          <img src={What} alt="What We Do" className="what-we-do-img" />
        </div>
        <div className="text-section">
          <div className="text-box">
            <h2 className="text-title">What We Do ?</h2>
            <p className="text-content">
              Syntiaro is an IT Solution based company looking to provide a more
              personal touch to an increasingly less personal industry. We aim
              to provide you with all the information you need and assist you
              with each step in the process. It provides IT Solutions with
              Advanced Technology. We develop solutions that are meant to
              enhance productivity and profitability by focusing on crucial
              business functions as well as auxiliary ones. We improve the
              functioning of elements such as sound communication and
              coordination between all departments, enterprises, travel agency,
              retail business, inventory management, restaurants management, and
              customer relationship management.
            </p>
          </div>
        </div>
      </section>

      <Softwares />
    </div>
  );
};

export default Aboutus;
