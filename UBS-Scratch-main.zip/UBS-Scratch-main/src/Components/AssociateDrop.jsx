import React from "react"; 
import { Link } from "react-router-dom";
import "../Components/Product.css";
import "../Layouts/Navbar.css";

const courses = [
  {
    name: "Individual Sales",
    path: "/sales"
  },
  {
    name: "B2B Partner",
    path: "/b2bpartner"
  }
];

const AssociateDrop = () => {
  return (
    <div className="course-container">
      <div className="grid">
        {courses.map((course, index) => (
          <div key={index} className="card-container">
            <Link to={course.path} className="card-link">
              <div className="card">
                <span>{course.name}</span>
              </div>
            </Link>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AssociateDrop;