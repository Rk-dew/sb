import React from "react";
import cafeMenu from "../assets/cafeMenu.jpg";
import Banner from "../assets/HomeMain.png";
import "../Components/Home.css";
import Software from "../assets/software.png";
import Crm from "../assets/crm.png";
import Salesman from "../assets/salesman.png";
import TravelAgency from "../assets/travelAgency.png";
import Indusind from "../assets/indusind-bank.png";
import Kotak from "../assets/Logo-Kotak-Mahindra.jpg";
import Bob from "../assets/BOB-logo.jpg";
import Sbi from "../assets/SBI-logo.jpg";
import Bom from "../assets/BOM-logo.jpg";
import Upi from "../assets/UPI-Black.png";
import Phonepay from "../assets/phonepay-logo.png";
import Gpay from "../assets/gpay-logo.webp";
import Paytm from "../assets/Paytm-logo.webp";
import Razorpay from "../assets/RazorPay-logo.jpg";
import Payu from "../assets/PayU-logo.jpg";
import demoImage from '../assets/demo-image.jpg';
import RetailPOS from "../assets/RetailPOS1.png";

import QSR from "../assets/qsr.png";
import CloudKitchen from "../assets/outlets/CloudKitchen.png";
import Cafe from "../assets/outlets/Cafe.png";
import FoodCourt from "../assets/outlets/FoodCourt.png";
import FoodChain from "../assets/outlets/FoodChain.png";
import FoodTruck from "../assets/outlets/FoodTruck.png";
import IceCreamDesert from "../assets/outlets/IceCreamDesert.png";
import Backery from "../assets/outlets/Backery1.png";
import Restaurant from "../assets/outlets/Restaurant.png";
import Hotel from "../assets/outlets/Hotel.png";
import ZomatoLogo from "../assets/Zomato.png";
import SwiggyLogo from "../assets/Swiggy.png";
import UberEatsLogo from "../assets/Uber.png";
import KFC from "../assets/KFC.jpg";
import Aroma from "../assets/Aroma.jpg";
import BurgerKing from "../assets/BurgerKing.png";
import GraceIndia from "../assets/GraceIndia.jpg";
import IndianFlames from "../assets/IndianFlames.jpg";
import IndianFood from "../assets/IndianFood.avif";
import RajvedhuImage from "../assets/RajvedhuImage.webp";
import ShopeeFood from "../assets/ShopeeFood.png";
import MobileIcon from "../assets/Mobile.png";
import TabletIcon from "../assets/Tablet.png";
import LaptopIcon from "../assets/Laptop.png";
import DesktopIcon from "../assets/Desktop.jpg";
import AndroidLogo from "../assets/Android.png";
import AppleLogo from "../assets/Apple.png";
import WindowsLogo from "../assets/Windows.png";
import LinuxLogo from "../assets/Linux.png";
import "bootstrap/dist/css/bootstrap.min.css";
import "../App.css";
import Google from "./GoogleReview";

const Home = () => {
  const userTypes = [
    {
      image: Software,
      count: "2000+",
      label: "POS Software Users",
      fontWeight: 600,
    },
    {
      image: Salesman,
      count: "1000+",
      label: "Salesman Tracker",
      fontWeight: 700,
    },
    {
      image: Crm,
      count: "250+",
      label: "CRM Software Users",
      fontWeight: 700,
    },
    {
      image: TravelAgency,
      count: "100+",
      label: "Travel Agency Software Users",
      fontWeight: 700,
    },
  ];

  const clients = [
    { name: "Indusind", logo: Indusind },
    { name: "Swagath", logo: Kotak },
    { name: "Tunday Kababi", logo: Bob },
    { name: "One Bite", logo: Sbi },
    { name: "Arsalan", logo: Bom },
    { name: "Pramod", logo: Upi },
    { name: "Al Kausar", logo: Phonepay },
    { name: "South Indian", logo: Gpay },
    { name: "Pramod", logo: Paytm },
    { name: "Al Kausar", logo: Razorpay },
    { name: "South Indian", logo: Payu },
  ];
  
  const partners = [
    { name: "BurgerKing", logo: BurgerKing },
    { name: "GraceIndia", logo: GraceIndia },
    { name: "IndianFlame", logo: IndianFlames },
    { name: "IndianFood", logo: IndianFood },
    { name: "Rajvedhulin", logo: RajvedhuImage },
    { name: "ShopeeFoc", logo: ShopeeFood },
    { name: "KFC", logo: KFC },
    { name: "Aroma", logo: Aroma },
  ];

  const outletData = [
    { icon: QSR, label: "QSR" },
    { icon: CloudKitchen, label: "Cloud Kitchens" },
    { icon: FoodCourt, label: "Food Court" },
    { icon: FoodChain, label: "Food Chain" },
    { icon: FoodTruck, label: "Food On Wheels" },
    { icon: IceCreamDesert, label: "Ice Cream & Desert" },
    { icon: Backery, label: "Bakeries" },
    { icon: Restaurant, label: "Restaurant" },
    { icon: Cafe, label: "Cafes" },
    { icon: Hotel, label: "Hotel" },
  ];

  return (
    <div className="home-page">
     <div className="hero-section-main">
        <div className="main-container">
          <div className="hero-content">
            <h1 className="headline">
              Revolutionize Your <span className="highlight">Restaurant Management</span>
            </h1>
            <p className="summary">
              The ultimate all-in-one solution designed to streamline operations for 
              <span className="text-gradient"> QSR, Cloud Kitchen, Food Court, Restarunt, Cafe, Hotel</span>. 
              Boost efficiency, reduce costs, and delight your customers.
            </p>
          </div>

          <div className="hero-image">
            <img src={Banner} alt="Restaurant Management Dashboard" className="banner-img" />
          </div>
        </div>
      </div>

      <div className="restaurant-system-section">
        <div className="system-container">
          <div className="system-image">
            <img src={cafeMenu} alt="Cafe Menu" />
          </div>

          <div className="system-content">
            <h2>Restaurant Billing Software</h2>
            <p>
              UBSBill stands as a premier provider of cloud-based, comprehensive technology
              solutions tailored for a diverse range of food businesses including QSR, Cloud Kitchen, Food Court, Backery, Restarunt, Cafe and Hotel.
            </p>
            <p>
              Our suite of services empowers food establishments, from individual outlets to expansive
              chains, to efficiently manage crucial operations such as billing, QR Code Ordering Platform,
              CRM, Customer Loyalty programs, Aggregator integrations, Analytics, Inventory, Recipe and
              Wastage Management, Centralized Menu Management, Vendor Management, and more.
            </p>
            <p>
              With a significant footprint, UBSBill has garnered the trust of over 2000+ customers across
              300+ cities and 10+ countries.
            </p>
          </div>
        </div>

        <div className="retail-system-section">
        <div className="system-container">
          <div className="system-content">
            <h2>Retail Billing Software</h2>
            <p>
              Our advanced Retail Billing Software simplifies daily operations for supermarkets, 
              convenience stores, fashion outlets, electronic shops, and more. 
              Designed to streamline the checkout process, manage stock efficiently, 
              and provide actionable analytics — all from a centralized, easy-to-use platform.
            </p>
            <p>
              With seamless POS features, inventory tracking, customer loyalty tools, 
              GST billing, barcode generation, and real-time reports, 
              UBSBill empowers retail businesses of all sizes to serve customers faster and better.
            </p>
            <p>
              Trusted by 2000+ retailers across the country, UBSBill is the smart solution 
              to take your retail business to the next level.
            </p>
          </div>

          <div className="retail-image">
            <img src={RetailPOS} alt="Retail Billing Software" />
          </div>
        </div>
      </div>


        <div className="integration-boxes">
        {/* First Container - Food Delivery */}
        <div className="parallelogram-box integration-card">
          <div className="box-content">
            <h4 className="box-title">Integration</h4>
            <div className="integration-logos">
              <img src={ZomatoLogo} alt="Zomato" className="food-logo" />
              <img src={SwiggyLogo} alt="Swiggy" className="food-logo" />
              <img src={UberEatsLogo} alt="Uber Eats" className="food-logo" />
            </div>
          </div>
        </div>
        
        {/* Second Container - Devices */}
        <div className="parallelogram-box device-card">
        <div className="box-content">
          <h4 className="box-title">Operating System's</h4>
            <div className="device-logos">
              <img src={MobileIcon} alt="Mobile" className="device-icon" />
              <img src={TabletIcon} alt="Tablet" className="device-icon" />
              <img src={DesktopIcon} alt="Desktop" className="device-icon" />
              <img src={LaptopIcon} alt="Laptop" className="device-icon" />
            </div>
          </div>
        </div>

        {/* Third Container - OS */}
        <div className="parallelogram-box os-card">
        <div className="box-content">
          <h4 className="box-title">Hardware</h4>
            <div className="os-logos">
              <img src={AndroidLogo} alt="Android" className="os-icon" />
              <img src={AppleLogo} alt="Apple" className="os-icon" />
              <img src={WindowsLogo} alt="Windows" className="os-icon" />
              <img src={LinuxLogo} alt="Linux" className="os-icon" />
            </div>
          </div>
        </div>
      </div>

      <div className="users-section">
        <div className="users-container">
          <h2>Trusted By Thousands</h2>
          <div className="users-grid">
            {userTypes.map((userType, index) => (
              <div key={index} className="user-card">
                <img src={userType.image} alt={userType.label} />
                <div className="user-count" style={{ fontWeight: userType.fontWeight }}>
                  {userType.count}
                </div>
                <div className="user-label" style={{ fontWeight: userType.fontWeight }}>
                  {userType.label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="partners-section"> 
        <div className="partners-container">
          <h2>Our Clients</h2>
          <div className="partners-slider">
            <div className="partners-track">
              {[...partners, ...partners].map((partner, index) => (
                <div key={index} className="partner-card">
                  <img src={partner.logo} alt={partner.name} />
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>


      <div className="highlights-section">
        <div className="highlights-container">
          <div className="highlight-text">
            <h2>Company highlights</h2>
            <p className="highlight-subtitle">Powering 2,000+ Restaurants</p>
          </div>
          <div className="highlight-stats">
            <div className="stat-card">
              <div className="icon">🍽️</div>
              <div className="count">1200+</div>
              <div className="label">Happy Restaurants</div>
            </div>
            <div className="stat-card">
              <div className="icon">🌍</div>
              <div className="count">30+</div>
              <div className="label">Cities</div>
            </div>
            <div className="stat-card">
              <div className="icon">💻</div>
              <div className="count">1</div>
              <div className="label">Platform</div>
            </div>
            <div className="stat-card">
              <div className="icon">🛒</div>
              <div className="count">10k+</div>
              <div className="label">Daily Orders</div>
            </div>
          </div>
        </div>
      </div>

      <div className="clients-section">
        <div className="clients-container">
          <h2>Our Partners</h2>
          <div className="clients-slider">
            <div className="clients-track">
              {[...clients, ...clients].map((client, index) => (
                <div key={index} className="client-card">
                  <img src={client.logo} alt={client.name} />
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>


      <div className="outlets-wrapper">
        <div className="outlets-section">
          <h2>Outlet Types</h2>
          <p className="outlet-subtitle">
            UBSBill's Restaurant Management POS is built for all types of restaurant sizes and formats from single outlets to 100+ outlet chains. 
            Select your format to see how UBSBill can help you run better.
          </p>
          <div className="outlets-grid">
            {outletData.map((outlet, index) => (
              <div key={index} className="outlet-card">
                <div className="outlet-icon-bg">
                  <img src={outlet.icon} alt={outlet.label} />
                </div>
                <p>{outlet.label}</p>
              </div>
            ))}
          </div>
        </div>
      </div>


      <div className="contact-page">
        <div className="con-container">
          {/* Left Form Section */}
          <div className="form-container">
          <h3 className="form-heading">Request Free Demo</h3> {/* Added heading */}
            <form className="demo-form">
              <input type="text" placeholder="Restaurant Name" required />
              <input type="text" placeholder="Owner Name" required />
              <input type="email" placeholder="Email" required />
  
              <div className="mobile-group">
                <select required>
                  <option value="+91">INDIA (+91)</option>
                  <option value="+1">USA (+1)</option>
                  <option value="+44">UK (+44)</option>
                </select>
                <input type="tel" placeholder="Owner Mobile" required />
              </div>
  
              <input type="text" placeholder="Enter city" required />
              <input type="text" placeholder="Enter Address" required />
  
              <button type="submit">Submit</button>
            </form>
          </div>
  
          {/* Right Side Image & Text */}
          <div className="image-container">
            <img src={demoImage} alt="Request Demo" />
          </div>
        </div>
      </div>
    </div>
    <div>
      <Google />
    </div>
    </div>
  );
};

export default Home;