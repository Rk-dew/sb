import React from "react";
import "./MVV.css";
import Value from "../assets/About/values.png";

const visionPoints = [
  {
    title: "Trustworthiness",
    description:
      "We build reliable POS solutions that help restaurants deliver better service and smoother operations.",
  },
  {
    title: "Customer-Centric",
    description:
      "Our systems focus on enhancing the customer journey and improving retail store efficiency.",
  },
  {
    title: "Innovation",
    description:
      "We create smart, intuitive tools to make everyday business tasks easier and more effective.",
  },
  {
    title: "Adaptability",
    description:
      "Our software evolves with changing needs, especially in educational and institutional sectors.",
  },
  {
    title: "Cost-Efficiency",
    description:
      "We provide affordable tools that simplify scheduling, management, and tracking in salons and spas.",
  },
  {
    title: "Responsibility",
    description:
      "We help monitor sales teams and improve performance through our Salesman Tracker.",
  },
];

const Values = () => {
  return (
    <section className="values-container">
      <div className="values-left">
        <img src={Value} alt="Our Values" className="values-img" />
      </div>

      <div className="values-right">
        <h2 className="values-title">Values</h2>
        <p className="values-subtitle">
          Getting the Most Value for Your POS Investment
        </p>
        <p className="values-description">
          Choosing the right POS system means investing in the future of your
          business. Our goal is to offer features that truly bring ROI,
          simplify tasks, and fit your business, team, and budget.
        </p>
        <ul className="values-list">
          {visionPoints.map((point, index) => (
            <li key={index}>
              <strong>{point.title}:</strong> {point.description}
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
};

export default Values;