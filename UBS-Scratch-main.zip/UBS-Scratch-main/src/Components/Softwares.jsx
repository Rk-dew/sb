import React from "react";
import "./MVV.css"; 
import Pos from "../assets/About/Pos.png";
import Tracker from "../assets/About/Tracker.png";
import Crm from "../assets/About/CRM2.png";
import Travel from "../assets/About/Travel.png";
import WhyUs from "../assets/About/WhyUS.png";
import Demo from "../assets/About/demo.png";
import Customer from "../assets/About/customerService.png";
import Support from "../assets/About/support.png";
import Quality from "../assets/About/quality.png";

const userTypes = [
  { image: Pos, label: "Restaurant POS Software", fontWeight: 600 },
  { image: Tracker, label: "Salesman Tracker", fontWeight: 700 },
  { image: Crm, label: "CRM Software", fontWeight: 700 },
  { image: Travel, label: "Travel Agency Software", fontWeight: 700 },
];

const userServices = [
  {
    image: Demo,
    label: "Free Online Demo",
    fontWeight: 600,
    data: "Our free demo will give you a first-hand view of a client's experiences when they use our software.",
  },
  {
    image: Customer,
    label: "Customer Service",
    fontWeight: 700,
    data: "We strive to provide superior customer service and ensure that every client is completely satisfied with our work.",
  },
  {
    image: Support,
    label: "Support",
    fontWeight: 700,
    data: "Our teams are trustworthy, dedicated and experienced and will go the extra mile to help you.",
  },
  {
    image: Quality,
    label: "Quality",
    fontWeight: 700,
    data: "We are committed to delivering outstanding, cutting edge business solutions that add real value that goes beyond what is expected.",
  },
];

function Softwares() {
  return (
    <div className="softwares-container">
      <div className="user-types">
        {userTypes.map((userType, index) => (
          <div key={index} className="user-type">
            <img src={userType.image} alt={userType.label} />
            <h3 style={{ fontWeight: userType.fontWeight }}>{userType.label}</h3>
          </div>
        ))}
      </div>

      {/* Why Choose Us Section */}
      <div className="why-choose-us">
        <div className="why-us-image">
          <img src={WhyUs} alt="Why Choose Us" />
        </div>
        <div className="why-us-text">
          <h2>Why Choose Us?</h2>
          <p>
            Syntiaro Solution have the expertise and resources required to design, develop and manage the highly available and highly secure technology platform that you need, giving you the time and confidence to focus on running your business. Here are 4 reasons why you should choose us to build your infrastructure, support your people and systems, enhance your productivity and give you a real competitive edge.
          </p>
        </div>
      </div>

      {/* Service Section */}
      {/* <div className="user-services">
        {userServices.map((user, index) => (
          <div key={index} className="user-service">
            <img src={user.image} alt={user.label} />
            <h3 style={{ fontWeight: user.fontWeight }}>{user.label}</h3>
            <p>{user.data}</p>
          </div>
        ))}
      </div> */}
    </div>
  );
}

export default Softwares;