import React from "react";
import "./MVV.css";
import VisionData from "../assets/About/mission.png";
import Vi1 from "../assets/About/vis.PNG";

const info = [
  {
    image: VisionData,
    label: "Vision",
    data: "At Syntiaro, our vision is to be the foremost provider of innovative and intuitive software solutions that empower businesses across diverse industries. We strive to be aa trusted partner in their growth journey, enhancing their efficiency, productivity, and customer satisfaction. We are committed to leading the way in software innovation, continuously exploring new technologies and trends to develop cutting-edge solutions. We envision a future where businesses can thrive by harnessing the full potential of digital tools. Our vision extends to achieving excellence in every industry we serve. We aim to be the go-to partner for businesses in the restaurant, garment, supermarket, education, salon/spa, and sales sectors, delivering tailored solutions that elevate their operations to new heights.",
  },
];
const Vision = () => {
  return (
    <section>
      <section
        className="vision-hero"
        style={{ backgroundImage: `url(${Vi1})` }}
      ></section>

      <section className="vision-section">
        {info.map((item, index) => (
          <div className="vision-container" key={index}>
            <div className="vision-image">
              <img src={item.image} alt="Vision Visual" />
            </div>
            <div className="vision-text">
              <h2 className="vision-title">{item.label}</h2>
              <p className="vision-description">{item.data}</p>
            </div>
          </div>
        ))}
      </section>
    </section>
  );
};

export default Vision;
