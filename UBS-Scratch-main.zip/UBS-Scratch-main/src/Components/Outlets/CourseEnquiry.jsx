import React, { useRef, useState, useEffect } from "react";
import axios from "axios";
import "../EnquiryPopup.css";
import { useLocation } from "react-router-dom";
import { CgClose } from "react-icons/cg"; // ✅ Icon import

const CourseEnquiry = () => {
  const [showPopup, setShowPopup] = useState(false);
  const [popupClosed, setPopupClosed] = useState(false);

  const location = useLocation();
  const { courseName = "", pdfFile = "" } = location.state || {};

  const downloadLinkRef = useRef(null);

  const [formData, setFormData] = useState({
    name: "",
    mobile: "",
    email: "",
    courseName: courseName,
  });

  // ✅ Show popup only if not manually closed
  useEffect(() => {
    if (!popupClosed) {
      setShowPopup(true);
    }
  }, [popupClosed]);

  const handleClose = () => {
    setShowPopup(false);
    setPopupClosed(true);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      console.log(formData);

      await axios.post("http://localhost:8080/course/add", formData);
      await axios.post("http://localhost:8080/email/sendCourse", formData);

      alert("Enquiry submitted successfully!");

      setFormData({
        name: "",
        mobile: "",
        email: "",
        courseName: courseName,
      });

      setShowPopup(false);
      setPopupClosed(true);

      // ✅ Trigger hidden syllabus PDF download
      if (downloadLinkRef.current) {
        downloadLinkRef.current.click();
      }
    } catch (error) {
      console.error("Error submitting inquiry:", error);
      alert("Failed to submit inquiry. Please try again.");
    }
  };

  return (
    <>
      {showPopup && (
        <div className="popup-overlay">
          <div className="popup-box">
            <button className="close-btn" onClick={handleClose}>
              <CgClose />
            </button>
            <h3>Course Inquiry Form</h3>
            <form onSubmit={handleSubmit}>
              <input
                type="text"
                name="name"
                placeholder="Name"
                value={formData.name}
                onChange={handleChange}
                required
              />
              <input
                type="tel"
                name="mobile"
                placeholder="Mobile Number"
                value={formData.mobile}
                onChange={handleChange}
                pattern="[0-9]{10}"
                required
              />
              <input
                type="email"
                name="email"
                placeholder="Email"
                value={formData.email}
                onChange={handleChange}
                required
              />
              <input
                type="text"
                name="courseName"
                placeholder="Course Name"
                value={formData.courseName}
                readOnly
              />
              <button type="submit">Submit</button>
            </form>

            {/* ✅ Hidden download link for syllabus PDF */}
            {pdfFile && (
              <a
                href={pdfFile}
                download
                ref={downloadLinkRef}
                style={{ display: "none" }}
              >
                Download
              </a>
            )}
          </div>
        </div>
      )}
    </>
  );
};

export default CourseEnquiry;