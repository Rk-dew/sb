import React from 'react';
import './sales.css';
import salesImage from '../assets/Sales.jpg';

const Sales = () => {
  return (
    <div className="sales-page">
      <div className="sales-container">
        <div className="sales-content-section">
          <h2>Become an sales partner</h2>
          <p>
            Partnering with us means becoming part of a fast-growing, future-ready brand that values
            collaboration, innovation, and growth. As an associate, you gain access to a proven business
            model, comprehensive training, and ongoing support that ensures your success. Whether you're a
            seasoned sales expert or a B2B partner, we provide the tools, technology, and trust to help you
            thrive. Join us to build strong networks, earn competitive rewards, and make a meaningful impact
            in the food-tech and restaurant automation industry.
          </p>
        </div>

        <div className="sales-form-image-wrapper">
          <div className="sales-form-section">
            <h3>Sales Person Form</h3>
            <form className="sales-form">
              <input type="text" placeholder="Name" required />
              <input type="text" placeholder="Contact" required />
              <input type="email" placeholder="Email" required />
              <select required>
                <option value="">Experience Duration</option>
                <option value="0-1">0-1</option>
                <option value="1-3">1-3</option>
                <option value="3-5">3-5</option>
                <option value="5-7">5-7</option>
                <option value="7+">7+</option>
              </select>
              <textarea placeholder="Tell us about yourself" rows="4"></textarea>
              <button type="submit">Submit</button>
            </form>
          </div>

          <div className="sales-image-section">
            <img src={salesImage} alt="Sales Person" />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Sales;