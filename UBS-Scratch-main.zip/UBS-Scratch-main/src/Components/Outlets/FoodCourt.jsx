import React from "react";
import Template from "./Template";



export default function FoodCourt() {
  return (
    <div>
      <Template
        header="Food Court Management"
        imageOne="/src/assets/outlets/FoodCourt.png"
        altOne="Food Court Management"
        content="We partner with food courts to unify operations across multiple counters, streamline billing, and enhance customer experience. Our tailored software solutions ensure real-time kitchen coordination, smart inventory tracking, and centralized control — helping food courts operate efficiently while boosting overall performance."
      />

    </div>
  );
}
