import React from "react";
import Template from "./Template";

export default function Juicery() {
  return (
    <div>
      <Template
        header="Juicery Management"
        imageOne="/src/assets/outlets/FoodCourt.png"
        altOne="Food Court Management"
        content="Keep your juicery fresh and flowing with our smart management solution designed for juice bars, smoothie counters, and detox cafés. From seasonal fruits to daily sales, our system helps you stay in complete control of your operations.

With features like real-time billing, customizable combos, and ingredient-based inventory tracking, you can serve up health and flavor with zero hassle. Track freshness, reduce wastage, and manage supplier stock seamlessly — all while enhancing your customer’s experience with faster checkouts and loyalty benefits."
      />
    </div>
  );
}
