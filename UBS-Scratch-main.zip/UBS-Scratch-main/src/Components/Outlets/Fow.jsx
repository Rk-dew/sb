import React from "react";
import Template from "./Template";


export default function Fow() {
  return (
    <div>
      <Template
        header="Food On Wheels"
        imageOne="/src/assets/outlets/FoodCourt.png"
        altOne="Food Court Management"
        content="We empower mobile food businesses with smart technology that moves with them. Our Food on Wheels solutions are crafted for food trucks, pop-up stalls, and mobile kitchens — enabling seamless operations whether you're parked at festivals, markets, or busy street corners.

From order-taking and digital invoicing to real-time inventory tracking and offline billing support, our platform ensures smooth service on the go. With GPS-based reporting, route optimization tools, and integrated payment options, you can manage your mobile kitchen from anywhere."
      />
    </div>
  );
}
