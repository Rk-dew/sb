import React from "react";
import "./Template.css";

export default function Template({
  header,
  imageOne,
  altOne = "Image One",
  content,
  onButtonClick,
  buttonText = "Book a Demo"
}) {
  return (
    <div className="hero-section">
      <div className="content-section">
        <div className="image-pair">
          <img src={imageOne} alt={altOne} />
        </div>
        <div className="content-text">
          <h2>{header}</h2>
          <p>{content}</p>
          <button className="demo-button" onClick={onButtonClick}>
            {buttonText}
          </button>
        </div>
      </div>
    </div>
  );
}