import React from "react";
import Template from "./Template";
import Retail from "../../assets/RetailPOS1.png";

export default function RetailPOS() {
  return (
    <div>
      <div className="retail-system-section">
        <div className="system-container">
          <div className="system-content">
            <h2>Retail Billing Software</h2>
            <p>
              Our advanced Retail Billing Software simplifies daily operations
              for supermarkets, convenience stores, fashion outlets, electronic
              shops, and more. Designed to streamline the checkout process,
              manage stock efficiently, and provide actionable analytics — all
              from a centralized, easy-to-use platform.
            </p>
            <p>
              With seamless POS features, inventory tracking, customer loyalty
              tools, GST billing, barcode generation, and real-time reports,
              UBSBill empowers retail businesses of all sizes to serve customers
              faster and better.
            </p>
            <p>
              Trusted by 1000+ retailers across the country, UBSBill is the
              smart solution to take your retail business to the next level.
            </p>
          </div>

          <div className="system-image">
            <img src={Retail} alt="Retail Billing Software" />
          </div>
        </div>
      </div>

      <Template
        header="Retail POS"
        imageOne="/src/assets/outlets/qsr.png"
        altOne="AI Collaboration"
        content="As strategic partners, we collaborate closely with clients, aligning our expertise with their goals. Through tailored solutions and open communication, we go beyond expectations, delivering innovative results and lasting value."
      />

    </div>
  );
}
