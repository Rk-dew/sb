import React from "react";
import Template from "./Template";



export default function Qsr() {
  return (
    <div>
      <Template
        header="QSR"
        imageOne="/src/assets/outlets/qsr.png"
        altOne="AI Collaboration"
        content="As strategic partners, we collaborate closely with clients, aligning our expertise with their goals. Through tailored solutions and open communication, we go beyond expectations, delivering innovative results and lasting value."
      />

      {/* <ServiceT /> */}
    </div>
  );
}
