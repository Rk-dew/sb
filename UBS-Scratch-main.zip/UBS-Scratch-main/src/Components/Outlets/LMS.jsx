import React from "react";
import Template from "./Template";
import cafeMenu from "../../assets/outlets/OutletP/lms.jpg";

export default function LMS() {
  return (
    <div>
      <div className="system-container">
        <div className="system-image">
          <img src={cafeMenu} alt="Cafe Menu" />
        </div>

        <div className="system-content">
          <h2>Learning Management System (LMS)</h2>
          <p>
            Our Learning Management System is a powerful, cloud-based platform
            designed to streamline and enhance the educational experience for
            institutions, training centers, and corporate organizations.
          </p>
          <p>
            The LMS empowers educators and administrators to manage and deliver
            courses efficiently with features like online classes, assessments,
            attendance tracking, progress analytics, content management,
            certification, and interactive learning tools. It supports blended
            learning, virtual classrooms, and mobile learning for seamless
            education anytime, anywhere.
          </p>
          <p>
            Trusted by 1000+ institutions and organizations across multiple
            cities, our LMS is the ideal solution for digital learning and
            training management.
          </p>
        </div>
      </div>

      <Template
        header="LMS Software"
        imageOne="/src/assets/outlets/qsr.png"
        altOne="AI Collaboration"
        content="Our LMS Software is a comprehensive, cloud-based solution built to revolutionize the way educational institutions, coaching centers, and corporate training programs manage learning and development."
      />
    </div>
  );
}
