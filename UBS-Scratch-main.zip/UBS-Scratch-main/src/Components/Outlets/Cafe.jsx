import React from "react";
import Template from "./Template";


export default function Cafe() {
  return (
    <div>
      <Template
        header="Cafe Management"
        imageOne="/src/assets/outlets/FoodCourt.png"
        altOne="Food Court Management"
        content="Crafted for cozy cafés and coffee houses, our Café Management Software simplifies day-to-day operations, from order processing to inventory tracking — so you can focus on creating great experiences for your customers.

Seamlessly handle dine-in, takeaway, and digital menu orders with an intuitive POS interface. Enable quick billing, manage loyalty programs, and offer personalized discounts — all while syncing with kitchen orders in real-time.

Track stock levels of ingredients, monitor best-selling items, and get smart analytics to guide menu decisions. Our solution supports you in reducing wait times, minimizing waste, and delivering consistent service."
      />
    </div>
  );
}
