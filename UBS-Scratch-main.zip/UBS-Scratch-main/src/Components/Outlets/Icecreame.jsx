import React from "react";
import Template from "./Template";

export default function Icecreame() {
  return (
    <div>
      <Template
        header="Icereams And Deserts"
        imageOne="/src/assets/outlets/FoodCourt.png"
        altOne="Food Court Management"
        content="Delight your customers and simplify your operations with our tailored software for ice cream parlors and dessert lounges. From managing scoops to sundaes, cakes to cold coffees — we streamline every aspect of your sweet business.

Our intuitive POS system ensures lightning-fast billing with support for combo offers, seasonal discounts, and multi-flavor customization. Real-time inventory tracking helps you monitor stock for perishables like dairy and toppings, while automated reports give insights into bestsellers and peak hours."
      />
    </div>
  );
}
