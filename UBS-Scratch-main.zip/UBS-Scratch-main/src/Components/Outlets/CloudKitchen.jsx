import React from "react";
import Template from "./Template";


export default function CloudKitchen() {
  return (
    <div>
      <Template
        header="Cloud Kitchen"
        imageOne="/src/assets/outlets/CloudKitchen.png"
        altOne="AI Collaboration"
        content="As strategic partners to cloud kitchens, we work closely with our clients to streamline operations, optimize delivery workflows, and enhance customer experiences. With customized solutions and clear communication, we empower cloud kitchens to scale efficiently, reduce overheads, and deliver consistent, high-quality food service."
      />

    </div>
  );
}
