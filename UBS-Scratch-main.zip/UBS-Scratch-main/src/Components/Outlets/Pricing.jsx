import React from 'react';
import './Pricing.css';
import demoImage from "../assets/demo-image.jpg"
const Pricing = () => {
  return (
    <div className="pricing-page">
      <h2 className="pricing-title">We want your restaurant to be profitable</h2>
      <p className="pricing-subtitle">Flexible and affordable pricing. Made for every growing business.</p>

      <div className="pricing-container">
        {/* Essential Plan */}
        <div className="pricing-card">
          <h3>First Year</h3>
          <p className="price">₹ 19,999*</p>
          <p className="renewal">first year/per outlet *including GST</p>
          <ul>
            <li>KOT Based Billing</li>
            <li>Quick Billing</li>
            <li>Cloud-based Billing</li>
            <li>Menu Management</li>
            <li>Inventory Management</li>
            <li>Mobile, Tablet, Desktop Support</li>
            <li>Technical Support 24X7</li>
          </ul>
          <br></br>
          <h5>Renewal Charges</h5>
          <p className="price" style={{fontSize: "25px"}}>₹7,499*</p>
          <p className="renewal">per year outlet charges from next year</p>
        </div>
      </div>
       <div className="contact-page">
              <div className="con-container">
                {/* Left Form Section */}
                <div className="form-container">
                <h3 className="form-heading">Request Free Demo</h3> {/* Added heading */}
                  <form className="demo-form">
                    <input type="text" placeholder="Restaurant Name" required />
                    <input type="text" placeholder="Owner Name" required />
                    <input type="email" placeholder="Email" required />
        
                    <div className="mobile-group">
                      <select required>
                        <option value="+91">INDIA (+91)</option>
                        <option value="+1">USA (+1)</option>
                        <option value="+44">UK (+44)</option>
                      </select>
                      <input type="tel" placeholder="Owner Mobile" required />
                    </div>
        
                    <input type="text" placeholder="Enter city" required />
                    <input type="text" placeholder="Enter Address" required />
        
                    <button type="submit">Submit</button>
                  </form>
                </div>
        
                {/* Right Side Image & Text */}
                <div className="image-container">
                  <img src={demoImage} alt="Request Demo" />
                </div>
              </div>
            </div>
    </div>
  );
};

export default Pricing;
