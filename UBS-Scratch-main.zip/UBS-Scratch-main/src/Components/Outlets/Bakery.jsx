import React from "react";
import Template from "./Template";

export default function Bakery() {
  return (
    <div>
      <Template
        header="Bakery Management"
        imageOne="/src/assets/outlets/FoodCourt.png"
        altOne="Food Court Management"
        content="From oven to order, streamline your bakery operations with our all-in-one management software built for bakeries, patisseries, and confectionery shops. Whether you're selling freshly baked breads, cakes, cookies, or custom desserts, our platform ensures smooth daily operations from kitchen to counter.

Handle real-time POS billing, manage ingredient-level inventory, automate pre-order tracking, and ensure timely deliveries — all from a single, intuitive dashboard. Our solution also supports batch tracking, expiry management, and seasonal menu customization to keep your bakery fresh and profitable.

Delight customers with personalized orders, loyalty rewards, and festive offers while you gain insights through detailed sales and performance reports."
      />
    </div>
  );
}
