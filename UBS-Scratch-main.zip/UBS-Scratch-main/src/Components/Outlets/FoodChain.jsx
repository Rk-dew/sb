import React from "react";
import Template from "./Template";

export default function FoodChain() {
  return (
    <div>
      <Template
        header="Food Chain Management"
        imageOne="/src/assets/outlets/FoodCourt.png"
        altOne="Food Court Management"
        content="Our solutions for food chains help unify operations across multiple outlets, ensuring consistent service, centralized control, and enhanced decision-making. With integrated billing, inventory, and analytics, we empower brands to scale efficiently and maintain operational excellence across all branches.

From quick-service restaurants to multi-location dine-in chains, we streamline kitchen workflows, enable real-time stock visibility, and improve turnaround time. Franchise-ready features allow flexible branding with a shared backend system.

Gain access to role-based dashboards, loyalty programs, supplier coordination, and smart performance reports — all from a single interface. Whether it's order syncing, recipe-level tracking, or chain-wide pricing updates, we make managing food chains simpler, smarter, and scalable."
      />
    </div>
  );
}
