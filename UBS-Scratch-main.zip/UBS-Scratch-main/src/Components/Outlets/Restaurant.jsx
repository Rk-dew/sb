import React from "react";
import Template from "./Template";


export default function Restaurant() {
  return (
    <div>
      <Template
        header="Restaurant Management"
        imageOne="/src/assets/outlets/FoodCourt.png"
        altOne="Food Court Management"
        content="Streamline your restaurant’s front and back operations with our comprehensive Restaurant Management Software. Designed for dine-in, takeaway, and delivery formats, it simplifies everything from table bookings and order taking to kitchen coordination and billing.

Boost your service efficiency with smart POS integration, real-time KOT updates, digital menus, and QR-based ordering. Manage your inventory, suppliers, and recipe costing with precision — ensuring you minimize wastage and maximize profit margins."
      />
    </div>
  );
}
