import React from "react";
import Template from "./Template";
import cafeMenu from "../../assets/cafeMenu.jpg";

export default function RestaurantPOS() {
  return (
    <div>


         <div className="system-container">
                  <div className="system-image">
                    <img src={cafeMenu} alt="Cafe Menu" />
                  </div>
        
                  <div className="system-content">
                    <h2>Restaurant Billing Software</h2>
                    <p>
                      UBSBill stands as a premier provider of cloud-based, comprehensive technology
                      solutions tailored for a diverse range of food businesses including Restaurants, Bars,
                      Cafés, QSRs, Ice-cream Shops, Bakeries, and Cake Shops.
                    </p>
                    <p>
                      Our suite of services empowers food establishments, from individual outlets to expansive
                      chains, to efficiently manage crucial operations such as billing, QR Code Ordering Platform,
                      CRM, Customer Loyalty programs, Aggregator integrations, Analytics, Inventory, Recipe and
                      Wastage Management, Centralized Menu Management, Vendor Management, and more.
                    </p>
                    <p>
                      With a significant footprint, UBSBill has garnered the trust of over 1500+ customers across
                      15+ cities.
                    </p>
                  </div>
                </div>



      <Template
        header="Empowering Innovation"
        imageOne="/src/assets/outlets/qsr.png"
        altOne="AI Collaboration"
        content="As strategic partners, we collaborate closely with clients, aligning our expertise with their goals. Through tailored solutions and open communication, we go beyond expectations, delivering innovative results and lasting value."
      />

    </div>
  );
}
