import React from "react";
import Template from "./Template";

export default function Hotel() {
  return (
    <div>
      <Template
        header="Hotel Management"
        imageOne="/src/assets/outlets/CloudKitchen.png"
        altOne="AI Collaboration"
        content="Our all-in-one Hotel Management Software is built to streamline operations across front desk, housekeeping, restaurant, and billing — providing guests with a seamless, luxurious experience from check-in to check-out.

Manage room bookings, availability, and guest profiles with ease. Automate billing, enable online reservations, and integrate restaurant or room service orders into one centralized system.

Real-time updates across departments ensure efficient coordination between front office, kitchen, and housekeeping, reducing delays and improving guest satisfaction."
      />
    </div>
  );
}
