import React from 'react';
import './Contact.css';
import ContactImage from "../assets/ContactImage.png"; // Make sure this path and image name is correct
import demoImage from '../assets/demo-image.jpg'; // Replace with your actual image path

const Contact = () => {
  return (
    <div>
      {/* Top Full-Width Image */}
      <div className="contact-top-image">
        <img src={ContactImage} alt="Contact Banner" />
      </div>

      {/* Contact Form Section */}
      <div className="contact-page">
        <div className="con-container">
          <div className="form-container">
            <form className="demo-form">
              <input type="text" placeholder="Restaurant Name" required />
              <input type="text" placeholder="Owner Name" required />
              <input type="email" placeholder="Email" required />

              <div className="mobile-group">
                <select required>
                  <option value="+91">INDIA (+91)</option>
                  <option value="+1">USA (+1)</option>
                  <option value="+44">UK (+44)</option>
                </select>
                <input type="tel" placeholder="Owner Mobile" required />
              </div>

              <input type="text" placeholder="Enter city" required />
              <input type="text" placeholder="Enter Address" required />

              <div className="recaptcha">
                <p>[Recaptcha]</p>
              </div>

              <button type="submit">Submit</button>
            </form>
          </div>

          {/* Optional right image/text */}
          <div className="image-container">
            <img src={demoImage} alt="Request Demo" />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;
