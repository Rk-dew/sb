import React from 'react';
import "../Components/Associate.css";

const Associate = () => {
  return (
    <div className="associate-page">

      {/* Container 1: Info Section */}
      <div className="associate-container info-container">
        <h2>Become an Associate</h2>
        <p>Partnering with us means becoming part of a fast-growing, future-ready brand that values collaboration, innovation, and growth. As an associate, you gain access to a proven business model, comprehensive training, and ongoing support that ensures your success. Whether you're a seasoned sales expert or a B2B partner, we provide the tools, technology, and trust to help you thrive. Join us to build strong networks, earn competitive rewards, and make a meaningful impact in the food-tech and restaurant automation industry.</p>
      </div>

      {/* Container 2: Sales Person Form */}
      <div className="associate-container sales-form-container">
        <h3>Sales Person Form</h3>
        <form className="associate-form">
          <input type="text" placeholder="Name" required />
          <input type="text" placeholder="Contact" required />
          <input type="email" placeholder="Email" required />

          <select required>
            <option value="">Experience Duration</option>
            <option value="0-1">0-1</option>
            <option value="1-3">1-3</option>
            <option value="3-5">3-5</option>
            <option value="5-7">5-7</option>
            <option value="7+">7+</option>
          </select>

          <textarea placeholder="Tell us about yourself" rows="4"></textarea>

          <button type="submit">Submit</button>
        </form>
      </div>

      {/* Container 3: B2B Form */}
      <div className="associate-container b2b-form-container">
        <h3>B2B Partnership Form</h3>
        <form className="associate-form">
          <input type="text" placeholder="Owner Name" required />
          <input type="text" placeholder="Company Name" required />
          <input type="text" placeholder="Company Address" required />
          <input type="text" placeholder="Company Location" required />
          <input type="email" placeholder="Company Email" required />
          <input type="text" placeholder="Official Number" required />
          <input type="url" placeholder="PDF Attachment Link" required />

          <textarea placeholder="Describe your partnership goals" rows="4"></textarea>

          <button type="submit">Submit</button>
        </form>
      </div>
    </div>
  );
};

export default Associate; 
