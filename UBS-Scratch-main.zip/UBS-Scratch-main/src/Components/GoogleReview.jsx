import React from 'react';
import './Google.css';

const GoogleReview = ({ reviewerName, reviewText, rating }) => {
  return (
    <div className="review-container">
      <div className="review-header">
        <h3 className="reviewer-name">{reviewerName}</h3>
        <div className="review-rating">{'★'.repeat(rating) + '☆'.repeat(5 - rating)}</div>
      </div>
      <p className="review-text">{reviewText}</p>
    </div>
  );
};

export default GoogleReview;