import React from "react"; 
import { Link } from "react-router-dom";
import "../Components/Product.css";
import "../Layouts/Navbar.css";

const courses = [
  {
    name: "QSR",
    path: "/qsr",
  },
  {
    name: "Cloud Kitchen",
    path: "/cloudkitchen",
  },
  {
    name: "Food Court",
    path: "/fc",
  },
  {
    name: "Food Chain",
    path: "/foodchain",
  },
  {
    name: "Food on Wheels",
    path: "/fow",
  },
  {
    name: "Icecreams & Deserts",
    path: "/i&d",
  },
  {
    name: "Juicery",
    path: "/juicery",
  },
  {
    name: "Bakery",
    path: "/bakery",
  },
  {
    name: "Restuarant",
    path: "/rest",
  },
  {
    name: "Cafe",
    path: "/cafe",
  },
  {
    name: "Hotel",
    path: "/hotel",
  }
];

const Outlettype = () => {
  return (
    <div className="course-container">
      <div className="grid">
        {courses.map((course, index) => (
          <div key={index} className="card-container">
            <Link to={course.path} className="card-link">
              <div className="card">
                <span>{course.name}</span>
              </div>
            </Link>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Outlettype;