import React from "react";
import { Container, Carousel, Row, Col } from "react-bootstrap";
import { FaQuoteLeft, FaQuoteRight } from "react-icons/fa";

const testimonials = [
  {
    text: `"Career Hub Technology provided the best hands-on training in full-stack development. The mentors were industry experts, and the projects helped me gain real-world experience."`,
    name: "Rohan Sharma",
  },
  {
    text: `"Enrolling in Career Hub Technology was the best decision for my career. The structured learning approach and job assistance helped me secure my first job as a software developer."`,
    name: "Priya Deshmukh",
  },
  {
    text: `"The Data Science bootcamp was intensive but rewarding. The hands-on projects and mentorship helped me build a strong portfolio, which landed me an internship."`,
    name: "Arjun Verma",
  },
  {
    text: `"The instructors at Career Hub Technology focus on real-world applications. The training gave me a solid foundation in DevOps, and now I am working in a reputed IT firm."`,
    name: "Megha Rane",
  },
  {
    text: `"Amazing support and guidance throughout the course. Career Hub helped me crack my first interview confidently!"`,
    name: "Ankit Joshi",
  },
  {
    text: `"I loved the community and the learning structure. The real-world projects gave me so much confidence."`,
    name: "Sneha Kulkarni",
  },
];

const Testimonials = () => {
  // Chunk testimonials into groups of 3
  const chunked = [];
  for (let i = 0; i < testimonials.length; i += 3) {
    chunked.push(testimonials.slice(i, i + 3));
  }

  return (
    <Container>
      <div style={styles.container}>
        <h2 style={styles.heading}>What Our Students Say</h2>
        <Carousel interval={5000} controls indicators>
          {chunked.map((group, idx) => (
            <Carousel.Item key={idx}>
              <Row className="justify-content-center">
                {group.map((t, i) => (
                  <Col key={i} md={4}>
                    <div style={styles.box}>
                      <p style={styles.text}>
                        <FaQuoteLeft style={{ color: "#fd6b17", marginRight: 5 }} />
                        {t.text}
                        <FaQuoteRight style={{ color: "#fd6b17", marginLeft: 5 }} />
                      </p>
                      <footer style={styles.footer}>{t.name}</footer>
                    </div>
                  </Col>
                ))}
              </Row>
            </Carousel.Item>
          ))}
        </Carousel>
      </div>
    </Container>
  );
};

const styles = {
  container: {
    textAlign: "center",
    padding: "2rem",
    backgroundColor: "#f8f9fa",
    borderRadius: "10px",
    boxShadow: "0 4px 10px rgba(0, 0, 0, 0.1)",
    maxWidth: "1200px",
    margin: "auto",
  },
  heading: {
    marginBottom: "30px",
    fontSize: "32px",
    color: "#2c3e50",
    fontWeight: "bold",
  },
  box: {
    backgroundColor: "white",
    padding: "20px",
    borderRadius: "10px",
    margin: "10px",
    minHeight: "230px",
    boxShadow: "0 2px 6px rgba(0, 0, 0, 0.1)",
    textAlign: "left",
  },
  text: {
    fontSize: "16px",
    fontStyle: "italic",
    color: "#444",
    lineHeight: "1.6",
  },
  footer: {
    fontSize: "16px",
    fontWeight: "bold",
    backgroundColor : "rgb(68 68 68)",
    color: "#ffffff",
    marginTop: "15px",
    textAlign: "center",
  },
};

export default Testimonials;