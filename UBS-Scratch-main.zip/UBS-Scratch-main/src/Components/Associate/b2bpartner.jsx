import React from 'react';
import './b2bpartner.css';
// import partnerImage from '../assets/b2b.jpg'; 

const B2BPartner = () => {
  return (
    <div className="b2b-partner-page">
      <div className="b2b-container">
        <div className="b2b-content-section">
          <h2>Become a B2B Partner</h2>
          <p>
            Join our network of trusted business partners and unlock new growth opportunities. 
            As a B2B partner, you'll gain access to exclusive benefits, priority support, 
            and collaborative solutions designed to drive mutual success. Whether you're 
            a supplier, distributor, or service provider, we offer tailored partnership 
            programs that create value for both organizations.
          </p>
        </div>

        <div className="b2b-form-image-wrapper">
          <div className="b2b-form-section">
            <h3>B2B Partnership Form</h3>
            <form className="b2b-form">
              <input type="text" placeholder="Owner Name" required />
              <input type="text" placeholder="Company Name" required />
              <input type="text" placeholder="Company Address" required />
              <input type="text" placeholder="Company Location" required />
              <input type="email" placeholder="Company Email" required />
              <input type="text" placeholder="Official Number" required />
              <input type="url" placeholder="PDF Attachment Link" required />
              <textarea placeholder="Describe your partnership goals" rows="4"></textarea>
              <button type="submit">Submit</button>
            </form>
          </div>

          <div className="b2b-image-section">
            {/* <img src={partnerImage} alt="B2B Partnership" /> */}
          </div>
        </div>
      </div>
    </div>
  );
};

export default B2BPartner;